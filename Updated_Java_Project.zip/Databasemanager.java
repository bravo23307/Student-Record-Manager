import java.sql.*;

public class DatabaseManager {
    private Connection conn;

    public DatabaseManager() {
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:students.db");
            try (Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("CREATE TABLE IF NOT EXISTS students (name TEXT, rollNo INTEGER PRIMARY KEY, marks INTEGER)");
            }
        } catch (SQLException e) {
            System.err.println("Database connection or table creation failed: " + e.getMessage());
        }
    }

    public String addStudent(String name, int rollNo, int marks) {
        if (name == null || name.trim().isEmpty() || rollNo <= 0 || marks < 0 || marks > 100) {
            return "Invalid student data!";
        }

        String sql = "INSERT INTO students (name, rollNo, marks) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setInt(2, rollNo);
            pstmt.setInt(3, marks);
            pstmt.executeUpdate();
            return "Student added successfully!";
        } catch (SQLException e) {
            return "Error adding student: " + e.getMessage();
        }
    }

    public ResultSet getAllStudents() {
        try {
            Statement stmt = conn.createStatement();
            return stmt.executeQuery("SELECT * FROM students");
        } catch (SQLException e) {
            System.err.println("Failed to retrieve students: " + e.getMessage());
            return null;
        }
    }
}
