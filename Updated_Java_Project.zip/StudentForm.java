import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class StudentForm extends JFrame {
    private JTextField nameField, rollField, marksField;
    private JTextArea displayArea;
    private DatabaseManager dbManager;

    public StudentForm() {
        dbManager = new DatabaseManager();

        setTitle("Student Record Manager");
        setLayout(null);
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(20, 20, 100, 20);
        add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(120, 20, 200, 20);
        add(nameField);

        JLabel rollLabel = new JLabel("Roll No:");
        rollLabel.setBounds(20, 60, 100, 20);
        add(rollLabel);

        rollField = new JTextField();
        rollField.setBounds(120, 60, 200, 20);
        add(rollField);

        JLabel marksLabel = new JLabel("Marks:");
        marksLabel.setBounds(20, 100, 100, 20);
        add(marksLabel);

        marksField = new JTextField();
        marksField.setBounds(120, 100, 200, 20);
        add(marksField);

        JButton addButton = new JButton("Add Student");
        addButton.setBounds(120, 140, 120, 30);
        add(addButton);

        JButton viewButton = new JButton("View All");
        viewButton.setBounds(250, 140, 120, 30);
        add(viewButton);

        displayArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(20, 190, 440, 250);
        add(scrollPane);

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addStudent();
            }
        });

        viewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                viewStudents();
            }
        });

        setVisible(true);
    }

    private void addStudent() {
        String name = nameField.getText().trim();
        int roll, marks;
        try {
            roll = Integer.parseInt(rollField.getText().trim());
            marks = Integer.parseInt(marksField.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Roll No and Marks must be integers.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String result = dbManager.addStudent(name, roll, marks);
        JOptionPane.showMessageDialog(this, result);
    }

    private void viewStudents() {
        displayArea.setText("");
        ResultSet rs = dbManager.getAllStudents();
        try {
            while (rs != null && rs.next()) {
                String student = "Name: " + rs.getString("name") + ", Roll No: " + rs.getInt("rollNo") + ", Marks: " + rs.getInt("marks");
                displayArea.append(student + "\n");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching students.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new StudentForm();
    }
}
